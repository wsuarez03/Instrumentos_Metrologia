# QR Instrumentos Metrología

Este proyecto permite:
- Descargar un Excel desde OneDrive (actualizado periódicamente)
- Convertirlo a JSON (`instrumentos.json`)
- Buscar instrumentos desde una app web (PWA) con QR dinámico

## Ejecutar

```bash
python generar_json.py
